package com.cg.bean;

public class Accounts_tbl {
private int acc_number;
private String insured_name;
private String  insured_city;
private String insured_area;
public int getAcc_number() {
	return acc_number;
}
public void setAcc_number(int acc_number) {
	this.acc_number = acc_number;
}
public String getInsured_name() {
	return insured_name;
}
public void setInsured_name(String insured_name) {
	this.insured_name = insured_name;
}
public String getInsured_city() {
	return insured_city;
}
public void setInsured_city(String insured_city) {
	this.insured_city = insured_city;
}
public String getInsured_area() {
	return insured_area;
}
public void setInsured_area(String insured_area) {
	this.insured_area = insured_area;
}
public Accounts_tbl(int acc_number, String insured_name, String insured_city, String insured_area) {
	super();
	this.acc_number = acc_number;
	this.insured_name = insured_name;
	this.insured_city = insured_city;
	this.insured_area = insured_area;
}
public Accounts_tbl() {
	super();
}

}
