package com.cg.bean;

public class answer_tbl {
	private int policy_number;
	private String answer_1;
	private int Weightage_1;
	private String answer_2;
	private int Weightage_2;
	private String answer_3;
	private int Weightage_3;
	private String answer_4;
	private int Weightage_4;
	private String answer_5;
	private int Weightage_5;
	public int getPolicy_number() {
		return policy_number;
	}
	public void setPolicy_number(int policy_number) {
		this.policy_number = policy_number;
	}
	public String getAnswer_1() {
		return answer_1;
	}
	public void setAnswer_1(String answer_1) {
		this.answer_1 = answer_1;
	}
	public int getWeightage_1() {
		return Weightage_1;
	}
	public void setWeightage_1(int weightage_1) {
		Weightage_1 = weightage_1;
	}
	public String getAnswer_2() {
		return answer_2;
	}
	public void setAnswer_2(String answer_2) {
		this.answer_2 = answer_2;
	}
	public int getWeightage_2() {
		return Weightage_2;
	}
	public void setWeightage_2(int weightage_2) {
		Weightage_2 = weightage_2;
	}
	public String getAnswer_3() {
		return answer_3;
	}
	public void setAnswer_3(String answer_3) {
		this.answer_3 = answer_3;
	}
	public int getWeightage_3() {
		return Weightage_3;
	}
	public void setWeightage_3(int weightage_3) {
		Weightage_3 = weightage_3;
	}
	public String getAnswer_4() {
		return answer_4;
	}
	public void setAnswer_4(String answer_4) {
		this.answer_4 = answer_4;
	}
	public int getWeightage_4() {
		return Weightage_4;
	}
	public void setWeightage_4(int weightage_4) {
		Weightage_4 = weightage_4;
	}
	public String getAnswer_5() {
		return answer_5;
	}
	public void setAnswer_5(String answer_5) {
		this.answer_5 = answer_5;
	}
	public int getWeightage_5() {
		return Weightage_5;
	}
	public void setWeightage_5(int weightage_5) {
		Weightage_5 = weightage_5;
	}
	public answer_tbl(int policy_number, String answer_1, int weightage_1, String answer_2, int weightage_2,
			String answer_3, int weightage_3, String answer_4, int weightage_4, String answer_5, int weightage_5) {
		super();
		this.policy_number = policy_number;
		this.answer_1 = answer_1;
		Weightage_1 = weightage_1;
		this.answer_2 = answer_2;
		Weightage_2 = weightage_2;
		this.answer_3 = answer_3;
		Weightage_3 = weightage_3;
		this.answer_4 = answer_4;
		Weightage_4 = weightage_4;
		this.answer_5 = answer_5;
		Weightage_5 = weightage_5;
	}
	public answer_tbl() {
		super();
	}
	

}
