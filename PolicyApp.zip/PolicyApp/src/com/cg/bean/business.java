package com.cg.bean;

public class business {
private String business_id;
private String business_seg;
public String getBusiness_id() {
	return business_id;
}
public void setBusiness_id(String business_id) {
	this.business_id = business_id;
}
public String getBusiness_seg() {
	return business_seg;
}
public void setBusiness_seg(String business_seg) {
	this.business_seg = business_seg;
}
public business(String business_id, String business_seg) {
	super();
	this.business_id = business_id;
	this.business_seg = business_seg;
}
public business() {
	super();
}

}
