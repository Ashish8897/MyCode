package com.cg.bean;

public class policy_tbl {
	private int acc_number;
private int policy_number;
private String business_id;
public int getAcc_number() {
	return acc_number;
}
public void setAcc_number(int acc_number) {
	this.acc_number = acc_number;
}
public int getPolicy_number() {
	return policy_number;
}
public void setPolicy_number(int policy_number) {
	this.policy_number = policy_number;
}
public String getBusiness_id() {
	return business_id;
}
public void setBusiness_id(String business_id) {
	this.business_id = business_id;
}
public policy_tbl(int acc_number, int policy_number, String business_id) {
	super();
	this.acc_number = acc_number;
	this.policy_number = policy_number;
	this.business_id = business_id;
}
public policy_tbl() {
	super();
}



}
