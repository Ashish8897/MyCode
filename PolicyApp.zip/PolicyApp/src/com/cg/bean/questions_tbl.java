package com.cg.bean;

public class questions_tbl {
private	String business_id;
	private String question_1;
	private String question_2;
	private String question_3;
	private String question_4;
	private String question_5;
	public String getBusiness_id() {
		return business_id;
	}
	public void setBusiness_id(String business_id) {
		this.business_id = business_id;
	}
	public String getQuestion_1() {
		return question_1;
	}
	public void setQuestion_1(String question_1) {
		this.question_1 = question_1;
	}
	public String getQuestion_2() {
		return question_2;
	}
	public void setQuestion_2(String question_2) {
		this.question_2 = question_2;
	}
	public String getQuestion_3() {
		return question_3;
	}
	public void setQuestion_3(String question_3) {
		this.question_3 = question_3;
	}
	public String getQuestion_4() {
		return question_4;
	}
	public void setQuestion_4(String question_4) {
		this.question_4 = question_4;
	}
	public String getQuestion_5() {
		return question_5;
	}
	public void setQuestion_5(String question_5) {
		this.question_5 = question_5;
	}
	public questions_tbl(String business_id, String question_1, String question_2, String question_3, String question_4,
			String question_5) {
		super();
		this.business_id = business_id;
		this.question_1 = question_1;
		this.question_2 = question_2;
		this.question_3 = question_3;
		this.question_4 = question_4;
		this.question_5 = question_5;
	}
	public questions_tbl() {
		super();
	}

}
