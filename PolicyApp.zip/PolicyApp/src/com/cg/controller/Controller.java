package com.cg.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.bean.Accounts_tbl;
import com.cg.service.Service;

/**
 * Servlet implementation class Controller
 */
@WebServlet("*.obj")
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Controller() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String path = request.getServletPath().trim();
		String username = null;
		String password=null;
		String role_code;
		String resource = null;
	Service service= new Service();
		switch (path) {

		case "/login.obj": username=request.getParameter("username");
		password=request.getParameter("password");
		role_code=null;

		role_code=service.checkUser(username, password);
	if(role_code.equals("admin"))
	{
		resource="admin.jsp";
	}
	
	else if(role_code.equals("agent"))
	{
		resource="admin.jsp";
	}
	else if(role_code.equals("insured"))
	{
		resource="admin.jsp";
	}
	else if(role_code.equals("null"))
	{
		resource="Login.jsp";
	}
	               
			break;

		case "/admin.obj":
			String choice=request.getParameter("createAccount");
			if(choice.equals("createAccount"))
			{
				resource="Login.jsp";
			}
			break;	
	
		}

		RequestDispatcher rd=request.getRequestDispatcher(resource);
		rd.include(request, response);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
