package com.cg.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.bean.Accounts_tbl;
import com.cg.bean.User_role;
import com.cg.service.Service;

/**
 * Servlet implementation class Controller
 */
@WebServlet("*.obj")
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Controller() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String path = request.getServletPath().trim();
		String username = null;
		String password=null;
		String role_code;
		String resource = null;
		User_role user=new User_role();
		
	Service service= new Service();
		switch (path) {

		case "/login.obj": username=request.getParameter("username");
		password=request.getParameter("password");
		role_code=null;

		role_code=service.checkUser(username, password);
	if(role_code.equals("admin"))
	{
		resource="admin.jsp";
	}
	
	else if(role_code.equals("agent"))
	{
		resource="agent.jsp";
	}
	else if(role_code.equals("insured"))
	{
		resource="user.jsp";
	}
	else if(role_code.equals("null"))
	{
		resource="Login.jsp";
	}
	               
			break;

		case "/CreateAccount.obj": 
			Accounts_tbl accounts= new Accounts_tbl();
		
			accounts.setInsured_name(request.getParameter("name"));
			accounts.setInsured_city(request.getParameter("city"));
			accounts.setInsured_area(request.getParameter("area"));
			System.out.println("called");
			 boolean acc_number1=service.CreateAccount(accounts);
			 System.out.println("here in");
			 
			 resource="acc_number.jsp";
			 
			 break;
			
			
	
		case "/create.obj":
			username=request.getParameter("user");
			password=request.getParameter("pass");
			role_code=request.getParameter("role");
			user.setUser_name(username);
			user.setPassword(password);
			user.setRole_code(role_code);
			if(service.createUser(user)){

		    
				resource="NewAccount.jsp";
			}
			else{
				resource="create.obj";
			}
			break;
		}

		RequestDispatcher rd=request.getRequestDispatcher(resource);
		rd.include(request, response);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
