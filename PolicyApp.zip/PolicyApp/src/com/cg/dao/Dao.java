package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.bean.Accounts_tbl;
import com.cg.bean.User_role;
import com.cg.bean.policy_tbl;
import com.cg.utility.DatabaseConnection;

public class Dao  implements IDaoInterface{


	DatabaseConnection db = new DatabaseConnection();
	Connection con = db.getConnection();
	PreparedStatement pstmt;
	String query;
	ResultSet rs;
	
	@Override
	public String checkUser(String user_name, String password) {
		String role_code = null;
		try {
			// System.out.println("in");

			pstmt = con.prepareStatement("select role_code from user_role where user_name=? and password=?");
			pstmt.setString(1, user_name);
			pstmt.setString(2, password);
		ResultSet rs= pstmt.executeQuery();
		
		if(rs.next()){
		role_code=rs.getString(1);
		}
		}
		 catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return role_code;
	}

	@Override
	public int CreateAccount(String user_name, String password) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public policy_tbl createPolicy(int acc_number) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean createUser(User_role user) {
		boolean flag = true;
		int n = 0;
		String username = user.getUser_name();
		String password1 = user.getPassword();
		String rolecode=user.getRole_code();
		String q2 = "insert into user_role values(?,?,?)";

		try {
			con = db.getConnection();
			System.out.println("here in try");
			PreparedStatement stmt1 = con.prepareStatement(q2);
				stmt1.setString(1, username);
				stmt1.setString(2, password1);
				stmt1.setString(3, rolecode);
				System.out.println("inside insert");
				n = stmt1.executeUpdate();
				flag = true;
				con.commit();	
			
		} catch (Exception e) {
			e.getStackTrace();
		}
		return flag;
	
		
	}

	@Override
	public Accounts_tbl CreateAccount(String user_name) {
		
		return null;
	}

	@Override
	public boolean CreateAccount(Accounts_tbl accounts) {
		
		String query="insert into accounts_tbl values(seq_1.nextval,?,?,?,?)";
		con= db.getConnection();
		try {
			System.out.println("a");
			PreparedStatement stmt1 = con.prepareStatement(query);
		
			stmt1.setString(1,accounts.getInsured_name() );
			stmt1.setString(2, accounts.getInsured_city());
			stmt1.setString(3, accounts.getInsured_area());
			stmt1.setString(4, accounts.getInsured_name());
			stmt1.executeUpdate();
			con.commit();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return true;
		
		
		
	
	}

	


	
	
}
