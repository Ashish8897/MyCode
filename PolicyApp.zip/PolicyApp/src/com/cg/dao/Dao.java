package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.bean.policy_tbl;
import com.cg.utility.DatabaseConnection;

public class Dao  implements IDaoInterface{


	DatabaseConnection db = new DatabaseConnection();
	Connection con = db.getConnection();
	PreparedStatement pstmt;
	String query;
	ResultSet rs;
	@Override
	public String checkUser(String user_name, String password) {
		String role_code = null;
		try {
			// System.out.println("in");

			pstmt = con.prepareStatement("select role_code from user_role where user_name=? and password=?");
			pstmt.setString(1, user_name);
			pstmt.setString(2, password);
		ResultSet rs= pstmt.executeQuery();
		
		if(rs.next()){
		role_code=rs.getString(1);
		}
		}
		 catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return role_code;
	}

	@Override
	public int CreateAccount(String user_name, String password) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public policy_tbl createPolicy(int acc_number) {
		// TODO Auto-generated method stub
		return null;
	}

}
