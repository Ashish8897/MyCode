package com.cg.dao;

import com.cg.bean.policy_tbl;

public interface IDaoInterface {
	public String checkUser(String user_name,String password);
	public int CreateAccount(String user_name,String password);
	public policy_tbl createPolicy( int acc_number);

}
