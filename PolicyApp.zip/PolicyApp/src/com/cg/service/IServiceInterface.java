package com.cg.service;

import com.cg.bean.Accounts_tbl;
import com.cg.bean.User_role;
import com.cg.bean.policy_tbl;

public interface IServiceInterface {
	public boolean createUser(User_role user);
	public String checkUser(String user_name,String password);
	public int CreateAccount(String user_name,String password);
	public policy_tbl createPolicy( int acc_number);
	public boolean CreateAccount(Accounts_tbl account);

}
