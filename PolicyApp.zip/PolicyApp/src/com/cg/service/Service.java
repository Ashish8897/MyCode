package com.cg.service;

import com.cg.bean.Accounts_tbl;
import com.cg.bean.User_role;
import com.cg.bean.policy_tbl;
import com.cg.dao.Dao;

public class Service implements IServiceInterface {
Dao d= new Dao();
	@Override
	public String checkUser(String user_name, String password) {
		 
		return d.checkUser(user_name, password);
	}

	@Override
	public int CreateAccount(String user_name, String password) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public policy_tbl createPolicy(int acc_number) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean createUser(User_role user) {
		// TODO Auto-generated method stub
		return d.createUser(user);
	}

	@Override
	public boolean CreateAccount(Accounts_tbl account) {
		return d.CreateAccount(account);

	}

}
