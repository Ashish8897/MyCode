package com.cg.utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
	Connection con=null;
	
	public Connection getConnection()
{ 
		String drivername="oracle.jdbc.OracleDriver";
	String url="jdbc:oracle:thin:@localhost:1521:xe";
	String username="system";
	String password="oracle";
	try {
		Class.forName(drivername);
		Connection con=DriverManager.getConnection(url, username, password);
		return con;
	} catch (SQLException | ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return null;
	
	}
}
